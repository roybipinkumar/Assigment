import React from 'react';
import './App.css';
import PackagingList from './PListState';

function App() {
  return (
    <div className="App">
      <PackagingList />
    </div>
  );
}

export default App;
