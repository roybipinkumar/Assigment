export const packagingItems = [
    { id: 1, item: 'shoes', isPacked: true, isHeavy: false },
    { id: 2, item: 'books', isPacked: false, isHeavy: true },
    { id: 3, item: 'laptop', isPacked: true, isHeavy: true },
    { id: 4, item: 'clothes', isPacked: false, isHeavy: false },
    { id: 5, item: 'camera', isPacked: true, isHeavy: false },
  ];
  