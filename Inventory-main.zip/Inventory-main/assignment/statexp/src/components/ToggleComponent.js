import React from 'react';

const ToggleComponent = () => {
  return (
    <div>
      <p>This is a toggleable component!</p>
    </div>
  );
};

export default ToggleComponent;
